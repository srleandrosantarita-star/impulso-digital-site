﻿# Análise de Hardware - coleta dados do PC e gera um relatório HTML com recomendações.
# Requer Windows 8.1/10/11 (PowerShell 3 ou mais novo, que já vem com o Windows).
# -Saida: usado internamente; a cópia de administrador grava ali o caminho do relatório para a cópia normal abrir.
param([string]$Saida)
[void][Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
function Aviso($texto) { [void][Windows.Forms.MessageBox]::Show($texto, 'Análise de Hardware', 'OK', 'Warning') }
if ($PSVersionTable.PSVersion.Major -lt 3) { Aviso 'Este Windows é antigo demais para a análise (precisa do Windows 8.1, 10 ou 11).'; exit 1 }
$ErrorActionPreference = 'SilentlyContinue'

# Abre o relatório numa janela própria (modo aplicativo do Edge ou Chrome); sem eles, no navegador padrão.
function AbrirJanela($arq) {
    $nav = $null
    foreach ($exe in 'msedge.exe', 'chrome.exe') {
        foreach ($raiz in 'HKLM:', 'HKCU:') {
            $c = (Get-ItemProperty "$raiz\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe").'(default)'
            if (-not $nav -and $c -and (Test-Path -LiteralPath $c)) { $nav = $c }
        }
    }
    if ($nav) { Start-Process $nav -ArgumentList "--app=`"$(([Uri]$arq).AbsoluteUri)`"", '--window-size=1100,900' }
    else { Start-Process $arq }
}

# Reabre como administrador (para ler temperatura e desgaste dos discos) e espera terminar.
# A janela do relatório é aberta por esta cópia normal, para o navegador não rodar como administrador.
$ehAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $ehAdmin -and -not $env:SEM_ADMIN) {
    $caminho = $MyInvocation.MyCommand.Path
    # unidade de rede mapeada (Z:) não existe na sessão de administrador: usa o caminho \\servidor\pasta
    $rede = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($caminho.Substring(0,2))' AND DriveType=4"
    if ($rede.ProviderName) { $caminho = $rede.ProviderName + $caminho.Substring(2) }
    $retorno = Join-Path $env:TEMP "analise_hardware_$PID.txt"
    try {
        Start-Process powershell -Verb RunAs -Wait -WindowStyle Hidden -ErrorAction Stop -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$caminho`" -Saida `"$retorno`""
        if (Test-Path -LiteralPath $retorno) {
            $arq = (Get-Content -LiteralPath $retorno | Select-Object -First 1)
            Remove-Item -LiteralPath $retorno
            if (-not $env:SEM_ABRIR) { AbrirJanela $arq }
        }
        exit
    } catch { }  # recusou a permissão: segue sem administrador
}

# Janela "Analisando..." com o logo e barra de progresso
$logoArq = Join-Path $PSScriptRoot 'logo.png'
Add-Type -AssemblyName System.Drawing
$tela = New-Object Windows.Forms.Form -Property @{ Text = 'Análise de Hardware'; ClientSize = New-Object Drawing.Size(420, 250)
    StartPosition = 'CenterScreen'; FormBorderStyle = 'FixedSingle'; MaximizeBox = $false; BackColor = [Drawing.Color]::White; TopMost = $true }
if (Test-Path -LiteralPath $logoArq) {
    $img = [Drawing.Image]::FromFile($logoArq)
    $tela.Icon = [Drawing.Icon]::FromHandle((New-Object Drawing.Bitmap($img, 64, 64)).GetHicon())
    $tela.Controls.Add((New-Object Windows.Forms.PictureBox -Property @{ Image = $img; SizeMode = 'Zoom'; Bounds = New-Object Drawing.Rectangle(20, 16, 380, 140) }))
}
$rotulo = New-Object Windows.Forms.Label -Property @{ Text = 'Analisando o computador...'; Bounds = New-Object Drawing.Rectangle(20, 168, 380, 24)
    TextAlign = 'MiddleCenter'; Font = New-Object Drawing.Font('Segoe UI', 10) }
$barra = New-Object Windows.Forms.ProgressBar -Property @{ Bounds = New-Object Drawing.Rectangle(40, 202, 340, 18); Maximum = 100 }
$tela.Controls.AddRange(@($rotulo, $barra))
$tela.Show()
function Etapa($texto, $pct) { $rotulo.Text = $texto; $barra.Value = $pct; [Windows.Forms.Application]::DoEvents() }
Etapa 'Lendo processador e memória...' 5

function Esc([object]$s) { [System.Net.WebUtility]::HtmlEncode([string]$s) }
function GB([double]$b, [int]$d = 1) { [math]::Round($b / 1GB, $d) }

function TamPasta($p) { if ($p -and (Test-Path -LiteralPath $p)) { [double](Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum } else { 0 } }

# Cada problema: nível (ruim/aviso/info), título, o que está acontecendo, passos para resolver e detalhes opcionais.
$problemas = New-Object System.Collections.ArrayList
function Problema($nivel, $titulo, $explicacao, [string[]]$passos, [string[]]$detalhes = @()) {
    [void]$problemas.Add([pscustomobject]@{ Nivel = $nivel; Titulo = $titulo; Explicacao = $explicacao; Passos = $passos; Detalhes = $detalhes })
}

# ---------- Coleta ----------
$cs    = Get-CimInstance Win32_ComputerSystem
$os    = Get-CimInstance Win32_OperatingSystem
$cpu   = @(Get-CimInstance Win32_Processor)
$bios  = Get-CimInstance Win32_BIOS
$placa = Get-CimInstance Win32_BaseBoard
$ram   = @(Get-CimInstance Win32_PhysicalMemory)
$slots = (Get-CimInstance Win32_PhysicalMemoryArray | Measure-Object MemoryDevices -Sum).Sum
$gpus  = @(Get-CimInstance Win32_VideoController)
Etapa 'Verificando os discos...' 20
$discosF = @(Get-PhysicalDisk | Sort-Object DeviceId)
if (-not $discosF.Count) {
    # alguns PCs (RAID, drivers antigos) não respondem ao Get-PhysicalDisk: usa a lista básica do Windows
    $discosF = @(Get-CimInstance Win32_DiskDrive | ForEach-Object {
        [pscustomobject]@{ FriendlyName = $_.Model; MediaType = ''; BusType = $_.InterfaceType; Size = [double]$_.Size
                           HealthStatus = $(if ($_.Status -eq 'OK') { 'Healthy' } else { 'Warning' }) } })
}
$vols  = @(Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3")
$bat   = @(Get-CimInstance Win32_Battery)
$redes = @(Get-NetAdapter -Physical | Where-Object Status -eq 'Up')
$carga = [math]::Round(($cpu | Measure-Object LoadPercentage -Average).Average)

# Temperatura (ACPI; nem todo PC informa e pode exigir administrador)
$temps = @(Get-CimInstance -Namespace root/wmi MSAcpi_ThermalZoneTemperature |
    ForEach-Object { [math]::Round($_.CurrentTemperature / 10 - 273.15) } | Where-Object { $_ -gt 0 -and $_ -lt 120 })

# Bateria: capacidade de projeto x atual
$desgaste = $null
if ($bat.Count) {
    $proj  = (Get-CimInstance -Namespace root/wmi BatteryStaticData | Select-Object -First 1).DesignedCapacity
    $atual = (Get-CimInstance -Namespace root/wmi BatteryFullChargedCapacity | Select-Object -First 1).FullChargedCapacity
    if ($proj -and $atual) { $desgaste = [math]::Round(100 - ($atual / $proj * 100)) }
}

# Dispositivos com defeito no Gerenciador de Dispositivos (ignora desativados e desconectados: 22, 24, 45)
$codigosPnp = @{ 1='não está configurado corretamente'; 3='driver corrompido'; 10='não consegue iniciar'; 12='conflito de recursos';
    14='precisa reiniciar o PC'; 18='driver precisa ser reinstalado'; 19='configuração corrompida'; 28='driver não instalado';
    31='driver não carregou'; 39='driver corrompido ou ausente'; 43='parou por falha (hardware ou driver)'; 52='driver sem assinatura digital' }
$pnpErro = @(Get-CimInstance Win32_PnPEntity -Filter 'ConfigManagerErrorCode <> 0' | Where-Object { $_.ConfigManagerErrorCode -notin 22, 24, 45 })

Etapa 'Procurando falhas registradas pelo Windows...' 40
# Falhas registradas pelo Windows nos últimos 30 dias
$desde = (Get-Date).AddDays(-30)
function Eventos($prov, [int[]]$ids) { @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = $prov; Id = $ids; StartTime = $desde } -ErrorAction SilentlyContinue) }
$evDisco     = @(Eventos 'disk' 7, 11, 51, 153)
$evNtfs      = @(Eventos 'Ntfs' 55) + @(Eventos 'Microsoft-Windows-Ntfs' 55)
$evQueda     = @(Eventos 'Microsoft-Windows-Kernel-Power' 41)
$evTelaAzul  = @(Eventos 'Microsoft-Windows-WER-SystemErrorReporting' 1001)
if (-not $evTelaAzul.Count) { $evTelaAzul = @(Eventos 'BugCheck' 1001) }
$evWheaGrave = @(Eventos 'Microsoft-Windows-WHEA-Logger' 1, 18, 46)
$evWheaCorr  = @(Eventos 'Microsoft-Windows-WHEA-Logger' 19, 47)

$inicio = @(Get-CimInstance Win32_StartupCommand | Where-Object { $_.Command } | Select-Object -ExpandProperty Name -Unique)
$reiniciarPendente = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') -or
                     (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')

# ---------- Análise ----------
Etapa 'Identificando problemas...' 60
$ramTotal = GB $cs.TotalPhysicalMemory
$ramLivre = GB ($os.FreePhysicalMemory * 1KB)
$ramUsoPct = [math]::Round(100 - ($os.FreePhysicalMemory * 1KB / $cs.TotalPhysicalMemory * 100))
$uptime = (Get-Date) - $os.LastBootUpTime

$tipoRam = @{ 20='DDR'; 21='DDR2'; 24='DDR3'; 26='DDR4'; 34='DDR5' }
$ehNotebook = $bat.Count -gt 0 -or $cs.PCSystemType -eq 2
$modeloPC = "$($cs.Manufacturer) $($cs.Model)".Trim()
function TopMemoria { Get-Process | Group-Object ProcessName | ForEach-Object { [pscustomobject]@{ N = $_.Name; MB = [math]::Round(($_.Group | Measure-Object WorkingSet64 -Sum).Sum / 1MB) } } |
    Sort-Object MB -Descending | Select-Object -First 5 | ForEach-Object { "$($_.N) — $($_.MB) MB" } }
function DataEv($e) { $e.TimeCreated.ToString('dd/MM/yyyy HH:mm') }

# --- Memória RAM ---
$pente = $ram | Select-Object -First 1
$sugestaoRam = "pente $($tipoRam[[int]$pente.SMBIOSMemoryType]) $(if ($pente.FormFactor -eq 12) { 'SODIMM (de notebook)' } else { 'DIMM (de desktop)' }) de $(GB $pente.Capacity 0) GB e $($pente.ConfiguredClockSpeed) MHz"
$temSlotLivre = $slots -and $ram.Count -lt $slots
$passosRam = @(
    $(if ($temSlotLivre) { "Instalar mais um $sugestaoRam no slot livre (igual ao atual, para ativar o dual channel)." } else { "Trocar os pentes atuais por outros de maior capacidade (mesmo tipo: $sugestaoRam)." }),
    'Enquanto isso: tirar da inicialização os programas que não são usados (Ctrl+Shift+Esc > Aplicativos de inicialização > Desabilitar).',
    'Evitar muitas abas abertas no navegador ao mesmo tempo.')
if ($ramTotal -lt 7.5) {
    Problema 'ruim' "Pouca memória RAM ($ramTotal GB)" 'Com menos de 8 GB o Windows usa o disco como memória extra, e o computador fica lento e trava com frequência.' $passosRam
} elseif ($ramTotal -lt 15 -and $ramUsoPct -ge 60) {
    Problema 'aviso' "Memória RAM no limite ($ramTotal GB, $ramUsoPct% em uso)" 'Com 8 GB o Windows funciona, mas fica lento com navegador e vários programas abertos. 16 GB é o recomendado hoje.' $passosRam
}
if ($ramUsoPct -ge 85) {
    Problema 'aviso' "Memória quase toda ocupada agora ($ramUsoPct%)" 'Os programas abaixo são os que mais estão usando memória neste momento.' @(
        'Fechar os programas que não estão sendo usados.', 'Se algum desconhecido aparecer na lista, passar o antivírus.', 'Se isso acontece sempre, aumentar a memória RAM.') @(TopMemoria)
}
if ($temSlotLivre -and $ram.Count -eq 1) {
    Problema 'info' 'Memória funcionando em canal simples' "Há um slot livre. Com dois pentes iguais a memória trabalha em dual channel, o que deixa o PC e o vídeo integrado mais rápidos." @("Instalar um $sugestaoRam no slot livre.")
}

# --- Discos ---
foreach ($d in $discosF) {
    $rel = $d | Get-StorageReliabilityCounter -ErrorAction SilentlyContinue
    $d | Add-Member -NotePropertyName Rel -NotePropertyValue $rel
    $nome = $d.FriendlyName
    if ($d.HealthStatus -and $d.HealthStatus -ne 'Healthy') {
        Problema 'ruim' "Disco '$nome' com defeito" 'O próprio disco está avisando que pode falhar a qualquer momento. Se falhar, os arquivos podem ser perdidos.' @(
            'Fazer backup IMEDIATAMENTE dos arquivos importantes (documentos, fotos, senhas do navegador).',
            'Evitar instalar programas ou baixar arquivos grandes até trocar o disco.',
            'Trocar o disco por um SSD novo e clonar o sistema para ele (ou reinstalar o Windows).')
    }
    if ($d.MediaType -eq 'HDD' -and $d.BusType -ne 'USB') {
        Problema 'aviso' "HD mecânico '$nome' (lento)" 'HDs mecânicos são 5 a 10 vezes mais lentos que SSDs. É a principal causa de lentidão para ligar o PC e abrir programas.' @(
            'Trocar por um SSD (SATA ou NVMe, conforme o que a placa aceita) de pelo menos 256 GB.',
            'Clonar o sistema do HD para o SSD, sem precisar reinstalar nada.',
            'O HD antigo pode continuar no PC (ou num case USB) para guardar arquivos.')
    }
    if ($rel.Wear -ge 80) {
        Problema 'ruim' "SSD '$nome' no fim da vida útil ($($rel.Wear)% usado)" 'Todo SSD aguenta um número limitado de gravações. Este já está perto do limite.' @('Fazer backup dos arquivos.', 'Planejar a troca do SSD em breve.')
    }
    if ($rel.Temperature -ge 60) {
        Problema 'aviso' "Disco '$nome' quente ($($rel.Temperature) °C)" 'Calor em excesso reduz a vida útil do disco e pode causar travamentos.' @('Limpar o pó das entradas e saídas de ar.', 'Em desktop: verificar se há ventilação passando pelo disco.')
    }
}
# Separa erros do disco interno dos de pen drive/HD externo (o 1º campo do evento é \Device\HarddiskN\...)
function PorDia($evs) { $evs | Group-Object { $_.TimeCreated.ToString('dd/MM/yyyy') } | Select-Object -First 5 | ForEach-Object { "$($_.Name) — $($_.Count) erro$(if ($_.Count -gt 1) { 's' })" } }
$internos = @(Get-CimInstance Win32_DiskDrive | Where-Object { $_.InterfaceType -ne 'USB' -and $_.MediaType -notmatch 'Removable|External' } | ForEach-Object { [int]$_.Index })
$evDiscoInt = @(); $evDiscoExt = @()
foreach ($e in $evDisco) {
    $m = [regex]::Match([string]$e.Properties[0].Value, 'Harddisk(\d+)')
    if ($m.Success -and [int]$m.Groups[1].Value -notin $internos) { $evDiscoExt += $e } else { $evDiscoInt += $e }
}
if ($evDiscoInt.Count) {
    Problema 'ruim' "Erros de leitura/gravação no disco interno ($($evDiscoInt.Count) nos últimos 30 dias)" 'O Windows registrou falhas ao acessar o disco do computador. Costuma ser sinal de disco começando a falhar ou de cabo/conexão com mau contato.' @(
        'Fazer backup dos arquivos importantes.',
        'Verificar o disco: abrir o Prompt de Comando como administrador, digitar  chkdsk C: /f /r , confirmar com S e reiniciar o PC.',
        $(if ($ehNotebook) { 'Se os erros continuarem, trocar o disco.' } else { 'Trocar o cabo SATA e a porta na placa-mãe; se os erros continuarem, trocar o disco.' })) @(PorDia $evDiscoInt)
}
if ($evDiscoExt.Count) {
    Problema 'aviso' "Erros em pen drive ou HD externo ($($evDiscoExt.Count) nos últimos 30 dias)" 'O Windows registrou falhas ao ler ou gravar em um dispositivo externo (pen drive, HD externo ou cartão de memória). O disco interno do computador não é o problema.' @(
        'Copiar os arquivos importantes desse dispositivo para outro lugar: ele pode estar falhando.',
        'Sempre clicar em "Ejetar" antes de remover o dispositivo.',
        'Testar com outro cabo e em outra porta USB, de preferência direto no computador (sem hub ou extensão).',
        'Verificar o dispositivo: conectar, abrir o Prompt de Comando como administrador e digitar  chkdsk X: /f  (trocando X pela letra dele).',
        'Se os erros continuarem, trocar o dispositivo.') @(PorDia $evDiscoExt)
}
if (-not $evDiscoInt.Count -and $evNtfs.Count) {
    Problema 'aviso' "Sistema de arquivos com erros ($($evNtfs.Count) nos últimos 30 dias)" 'O Windows encontrou arquivos ou pastas corrompidos no disco.' @(
        'Abrir o Prompt de Comando como administrador, digitar  chkdsk C: /f , confirmar com S e reiniciar.',
        'Depois, rodar  sfc /scannow  no mesmo Prompt para reparar arquivos do Windows.')
}

# --- Espaço em disco ---
Etapa 'Calculando espaço em disco...' 75
foreach ($v in $vols) {
    if (-not $v.Size) { continue }
    $pct = [math]::Round($v.FreeSpace / $v.Size * 100)
    if ($pct -ge 20) { continue }
    $nivel = if ($pct -lt 10) { 'ruim' } else { 'aviso' }
    $ehSistema = $v.DeviceID -eq $env:SystemDrive
    $detalhes = @()
    if ($ehSistema) {
        $perfil = [Environment]::GetFolderPath('UserProfile')
        $lixeira = [double]((New-Object -ComObject Shell.Application).Namespace(10).Items() | ForEach-Object { $_.ExtendedProperty('Size') } | Measure-Object -Sum).Sum
        $itens = [ordered]@{
            'Arquivos temporários'            = (TamPasta $env:TEMP) + (TamPasta "$env:windir\Temp")
            'Lixeira'                         = $lixeira
            'Downloads'                       = TamPasta "$perfil\Downloads"
            'Cache do Windows Update'         = TamPasta "$env:windir\SoftwareDistribution\Download"
            'Windows.old (instalação antiga)' = TamPasta "$env:SystemDrive\Windows.old"
        }
        $detalhes = @($itens.GetEnumerator() | Where-Object { $_.Value -ge 100MB } | Sort-Object Value -Descending | ForEach-Object { "$($_.Key): $(GB $_.Value) GB" })
        $passos = @(
            'Abrir Configurações > Sistema > Armazenamento > Arquivos temporários, marcar os itens e clicar em Remover (isso limpa temporários, cache de atualizações e Windows.old).',
            'Esvaziar a Lixeira.',
            'Revisar a pasta Downloads e apagar instaladores e arquivos que não precisa mais.',
            'Desinstalar programas e jogos que não usa (Configurações > Aplicativos).',
            'Mover fotos, vídeos e músicas para um HD externo ou para a nuvem.')
        if ($v.Size -lt 200GB) { $passos += "Se continuar faltando espaço: trocar o disco de $(GB $v.Size 0) GB por um SSD de 256 GB ou 512 GB." }
        $expl = "Com pouco espaço livre o Windows fica lento, não consegue instalar atualizações e pode travar." + $(if ($detalhes.Count) { ' Espaço que dá para recuperar:' } else { '' })
    } else {
        $passos = @('Apagar ou mover para outro lugar os arquivos que não precisa mais.', 'Esvaziar a Lixeira.')
        $expl = 'Esta unidade está quase sem espaço para novos arquivos.'
    }
    Problema $nivel "Unidade $($v.DeviceID) quase cheia ($(GB $v.FreeSpace) GB livres, $pct%)" $expl $passos $detalhes
}

# --- Temperatura, energia e bateria ---
$tempMax = if ($temps.Count) { ($temps | Measure-Object -Maximum).Maximum } else { 0 }
if ($tempMax -ge 85) {
    Problema 'ruim' "Temperatura alta ($tempMax °C)" 'Calor em excesso deixa o PC lento (o processador reduz a velocidade para se proteger), causa travamentos e desligamentos, e diminui a vida útil das peças.' @(
        'Limpar o pó das ventoinhas e saídas de ar (ar comprimido ou soprador).',
        'Trocar a pasta térmica do processador (recomendado a cada 2 ou 3 anos).',
        $(if ($ehNotebook) { 'Usar o notebook em superfície dura e plana (nunca em cama, sofá ou almofada); uma base com cooler ajuda.' } else { 'Verificar se todas as ventoinhas do gabinete estão girando.' }))
}
if ($evQueda.Count) {
    $nivel = if ($evQueda.Count -ge 3) { 'ruim' } else { 'aviso' }
    Problema $nivel "Desligamentos inesperados ($($evQueda.Count) nos últimos 30 dias)" 'O PC desligou ou reiniciou sem passar pelo desligamento normal. Causas comuns: queda de energia, travamento, superaquecimento ou fonte com defeito. (Segurar o botão de ligar para forçar o desligamento também conta.)' @(
        'Ligar o PC num nobreak ou num filtro de linha de qualidade.',
        'Limpar o pó e verificar as temperaturas.',
        $(if ($ehNotebook) { 'Testar com outro carregador original e verificar a bateria.' } else { 'Testar ou trocar a fonte de alimentação (fontes genéricas são causa comum).' }),
        'Atualizar os drivers pelo Windows Update (Atualizações opcionais) e a BIOS pelo site do fabricante.') @($evQueda | Select-Object -First 5 | ForEach-Object { DataEv $_ })
}
if ($evTelaAzul.Count) {
    $nivel = if ($evTelaAzul.Count -ge 2) { 'ruim' } else { 'aviso' }
    Problema $nivel "Tela azul ($($evTelaAzul.Count) nos últimos 30 dias)" 'O Windows travou com erro grave e reiniciou. Geralmente é causado por driver com problema, memória RAM com defeito ou disco falhando.' @(
        'Instalar todas as atualizações do Windows, incluindo as opcionais de drivers (Configurações > Windows Update > Opções avançadas > Atualizações opcionais).',
        'Testar a memória: aperte Win+R, digite  mdsched  e escolha "Reiniciar agora e verificar".',
        'Verificar o disco com  chkdsk C: /f /r  (Prompt de Comando como administrador).',
        'Se começou depois de instalar algum programa, driver ou peça nova, desfazer essa mudança.') @($evTelaAzul | Select-Object -First 5 | ForEach-Object {
            $cod = [regex]::Match($_.Message, '0x[0-9a-fA-F]{8}').Value; "$(DataEv $_)$(if ($cod) { " — código $cod" })" })
}
if ($evWheaGrave.Count) {
    Problema 'ruim' "Erro grave de hardware registrado ($($evWheaGrave.Count) nos últimos 30 dias)" 'O processador, a memória ou a placa-mãe relataram uma falha física. É o tipo de erro que causa travamentos e telas azuis.' @(
        'Testar a memória com  mdsched  (Win+R).', 'Verificar as temperaturas e limpar o pó.',
        'Remover qualquer overclock e atualizar a BIOS pelo site do fabricante.', 'Se continuar, levar para avaliação técnica das peças.') @($evWheaGrave | Select-Object -First 5 | ForEach-Object { DataEv $_ })
} elseif ($evWheaCorr.Count -ge 10) {
    Problema 'aviso' "Erros de hardware corrigidos ($($evWheaCorr.Count) nos últimos 30 dias)" 'O hardware teve falhas que conseguiu corrigir sozinho. Muitos erros assim podem indicar memória ou processador começando a dar problema.' @(
        'Testar a memória com  mdsched  (Win+R).', 'Atualizar a BIOS e os drivers do chipset pelo site do fabricante.')
}
if ($desgaste -ne $null -and $desgaste -ge 20) {
    $nivel = if ($desgaste -ge 40) { 'ruim' } else { 'aviso' }
    Problema $nivel "Bateria desgastada (perdeu $desgaste% da capacidade)" 'A bateria segura bem menos carga do que quando era nova, e o notebook descarrega mais rápido.' @(
        "Trocar a bateria por uma nova compatível com o modelo $modeloPC.",
        'Evitar deixar o notebook descarregar até 0% e muito tempo no calor.',
        'Se o fabricante tiver opção de limitar a carga a 80% (ex.: HP, Lenovo, Dell, Samsung), ativar para durar mais.')
}

# --- Drivers e dispositivos ---
if ($pnpErro.Count) {
    Problema 'ruim' "$($pnpErro.Count) dispositivo(s) com problema" 'Algumas peças do computador não estão funcionando direito, geralmente por falta de driver ou driver com defeito.' @(
        'Abrir Configurações > Windows Update > Opções avançadas > Atualizações opcionais e instalar os drivers oferecidos.',
        "Baixar os drivers no site de suporte do fabricante, procurando pelo modelo: $modeloPC.",
        'No Gerenciador de Dispositivos (botão direito no Iniciar), clicar com o botão direito no dispositivo > Desinstalar dispositivo, e reiniciar o PC.',
        'Se for um dispositivo USB, testar em outra porta e com outro cabo.') @($pnpErro | ForEach-Object {
            "$($_.Name) — $(if ($codigosPnp[[int]$_.ConfigManagerErrorCode]) { $codigosPnp[[int]$_.ConfigManagerErrorCode] } else { 'erro ' + $_.ConfigManagerErrorCode })" })
}
foreach ($g in $gpus) {
    if ($g.Name -match 'Basic Display|Vídeo Básico|Basic Render') {
        Problema 'ruim' 'Placa de vídeo sem driver' 'O Windows está usando um driver genérico: imagem com resolução errada, vídeos travando e jogos sem funcionar.' @(
            'Instalar o driver de vídeo pelo Windows Update (Atualizações opcionais).', "Ou baixar no site do fabricante do computador ($modeloPC).")
    } elseif ($g.DriverDate -and ([datetime]$g.DriverDate) -lt (Get-Date).AddYears(-3)) {
        $site = if ($g.Name -match 'NVIDIA') { 'NVIDIA App (nvidia.com)' } elseif ($g.Name -match 'AMD|Radeon') { 'AMD Software Adrenalin (amd.com)' } elseif ($g.Name -match 'Intel') { 'Intel Driver & Support Assistant (intel.com.br)' } else { 'site do fabricante da placa' }
        Problema 'aviso' "Driver de vídeo desatualizado ($(([datetime]$g.DriverDate).ToString('MM/yyyy')))" "O driver da $($g.Name) tem mais de 3 anos. Drivers novos corrigem travamentos, falhas em vídeos e melhoram o desempenho." @(
            "Atualizar pelo $site.",
            $(if ($ehNotebook) { "Em notebook, se o instalador recusar, usar o driver do site do fabricante do notebook ($modeloPC)." } else { 'Reiniciar o PC depois de instalar.' }))
    }
}

# --- Processador ---
if ($carga -ge 90) {
    $nLog = ($cpu | Measure-Object NumberOfLogicalProcessors -Sum).Sum
    $topCpu = Get-CimInstance Win32_PerfFormattedData_PerfProc_Process | Where-Object { $_.Name -notin '_Total', 'Idle' } |
        Sort-Object PercentProcessorTime -Descending | Select-Object -First 5 | ForEach-Object { "$($_.Name -replace '#\d+$', '') — $([math]::Round($_.PercentProcessorTime / $nLog))%" }
    Problema 'aviso' "Processador sobrecarregado agora ($carga%)" 'Os programas abaixo são os que mais estão usando o processador neste momento.' @(
        'Fechar os programas pesados que não estão sendo usados.', 'Se algum programa desconhecido aparecer na lista, passar o antivírus.',
        'Se o PC fica lento o tempo todo, verificar temperatura e programas que iniciam com o Windows.') @($topCpu)
}

# --- Sistema ---
if ($os.Caption -match 'Windows 10') {
    Problema 'aviso' 'Windows 10 sem suporte' 'A Microsoft parou de lançar atualizações de segurança gratuitas para o Windows 10 em 14/10/2025. O PC fica mais exposto a vírus e golpes.' @(
        'Verificar se o PC aceita o Windows 11: instalar o app "Verificação de Integridade do PC" da Microsoft.',
        'Se aceitar: Configurações > Windows Update > Atualizar para o Windows 11 (é gratuito).',
        'Se não aceitar: aderir às Atualizações de Segurança Estendidas (ESU) em Configurações > Windows Update, ou planejar a troca do computador.')
}
if ($reiniciarPendente) {
    Problema 'aviso' 'Atualização esperando reinicialização' 'O Windows instalou atualizações que só terminam depois de reiniciar. Até lá, podem aparecer lentidão e erros.' @('Salvar os trabalhos abertos e reiniciar o PC (Iniciar > Energia > Reiniciar).')
} elseif ($uptime.TotalDays -ge 7) {
    Problema 'info' "PC ligado há $([int]$uptime.TotalDays) dias sem reiniciar" "O botão Desligar do Windows não zera a memória (inicialização rápida). Reiniciar de vez em quando limpa a memória e aplica atualizações." @('Usar Iniciar > Energia > Reiniciar pelo menos uma vez por semana.')
}
if ($inicio.Count -gt 8) {
    Problema 'info' "$($inicio.Count) programas iniciam junto com o Windows" 'Cada programa que abre sozinho deixa o PC mais demorado para ligar e ocupa memória.' @(
        'Apertar Ctrl+Shift+Esc > Aplicativos de inicialização.', 'Clicar com o botão direito nos que não precisam abrir sozinhos > Desabilitar (não apaga o programa).') @($inicio | Select-Object -First 15)
}

# Nota geral
$graves  = @($problemas | Where-Object Nivel -eq 'ruim').Count
$atencao = @($problemas | Where-Object Nivel -eq 'aviso').Count
$dicas   = @($problemas | Where-Object Nivel -eq 'info').Count
$nota = [math]::Max(0, 100 - 20 * $graves - 8 * $atencao)
$notaTxt = if ($nota -ge 85) { 'Ótimo' } elseif ($nota -ge 60) { 'Bom, com pontos de atenção' } else { 'Precisa de atenção' }
$notaCls = if ($nota -ge 85) { 'ok' } elseif ($nota -ge 60) { 'aviso' } else { 'ruim' }

# ---------- HTML ----------
Etapa 'Montando o relatório...' 90
function Linhas($pares) { ($pares | Where-Object { $_[1] -ne $null -and "$($_[1])" -ne '' } | ForEach-Object { "<tr><th>$(Esc $_[0])</th><td>$(Esc $_[1])</td></tr>" }) -join '' }
function Barra($pct) {
    $c = if ($pct -ge 90) { 'ruim' } elseif ($pct -ge 75) { 'aviso' } else { 'ok' }
    "<div class='barra'><span class='$c' style='width:$pct%'></span></div>"
}

$sec = @()
$sec += "<section><h2>Processador</h2>" + ($cpu | ForEach-Object { "<table>" + (Linhas @(
    @('Modelo', $_.Name.Trim()), @('Núcleos / Threads', "$($_.NumberOfCores) / $($_.NumberOfLogicalProcessors)"),
    @('Frequência base', "$([math]::Round($_.MaxClockSpeed/1000,2)) GHz"), @('Uso agora', "$carga%"))) + "</table>" + (Barra $carga) }) + "</section>"

$sec += "<section><h2>Memória RAM</h2><table>" + (Linhas @(
    @('Total', "$ramTotal GB"), @('Em uso', "$ramUsoPct% ($ramLivre GB livres)"), @('Pentes / slots', "$($ram.Count) de $slots"))) + "</table>" + (Barra $ramUsoPct) +
    "<table class='lista'><tr><th>Slot</th><th>Tamanho</th><th>Tipo</th><th>Velocidade</th><th>Fabricante</th></tr>" +
    (($ram | ForEach-Object { "<tr><td>$(Esc $_.DeviceLocator)</td><td>$(GB $_.Capacity 0) GB</td><td>$(Esc $tipoRam[[int]$_.SMBIOSMemoryType])</td><td>$(Esc $_.ConfiguredClockSpeed) MHz</td><td>$(Esc $_.Manufacturer)</td></tr>" }) -join '') + "</table></section>"

$sec += "<section><h2>Discos</h2><table class='lista'><tr><th>Disco</th><th>Tipo</th><th>Tamanho</th><th>Saúde</th><th>Temp.</th><th>Desgaste</th><th>Horas ligado</th></tr>" +
    (($discosF | ForEach-Object {
        $cls = if ($_.HealthStatus -eq 'Healthy') { 'ok' } else { 'ruim' }
        $saude = @{ Healthy='Saudável'; Warning='Atenção'; Unhealthy='Com defeito' }[[string]$_.HealthStatus]
        "<tr><td>$(Esc $_.FriendlyName)</td><td>$(Esc (@{ HDD='HD'; SSD='SSD'; SCM='SCM' }[[string]$_.MediaType], 'Tipo desconhecido' | Where-Object { $_ } | Select-Object -First 1)) · $(Esc $_.BusType)</td><td>$(GB $_.Size 0) GB</td><td><b class='$cls'>$(Esc $saude)</b></td><td>$(if($_.Rel.Temperature){"$($_.Rel.Temperature) °C"}else{'—'})</td><td>$(if($_.Rel.Wear -ne $null){"$($_.Rel.Wear)%"}else{'—'})</td><td>$(if($_.Rel.PowerOnHours){$_.Rel.PowerOnHours}else{'—'})</td></tr>"
    }) -join '') + "</table><h3>Espaço</h3>" +
    (($vols | ForEach-Object { $usado = [math]::Round(100 - $_.FreeSpace / $_.Size * 100)
        "<div class='vol'><span>$(Esc $_.DeviceID) $(Esc $_.VolumeName)</span><span>$(GB $_.FreeSpace) GB livres de $(GB $_.Size) GB</span></div>" + (Barra $usado) }) -join '') + "</section>"

$sec += "<section><h2>Placa de vídeo</h2>" + (($gpus | ForEach-Object { "<table>" + (Linhas @(
    @('Modelo', $_.Name), @('Memória', $(if ($_.AdapterRAM -gt 0) { "$(GB ([uint32]$_.AdapterRAM)) GB" })),
    @('Resolução', $(if ($_.CurrentHorizontalResolution) { "$($_.CurrentHorizontalResolution) x $($_.CurrentVerticalResolution) @ $($_.CurrentRefreshRate) Hz" })),
    @('Driver', "$($_.DriverVersion) ($(([datetime]$_.DriverDate).ToString('dd/MM/yyyy')))"))) + "</table>" }) -join '') + "</section>"

$sec += "<section><h2>Placa-mãe e sistema</h2><table>" + (Linhas @(
    @('Computador', "$($cs.Manufacturer) $($cs.Model)"), @('Placa-mãe', "$($placa.Manufacturer) $($placa.Product)"),
    @('BIOS', "$($bios.SMBIOSBIOSVersion) ($(([datetime]$bios.ReleaseDate).ToString('dd/MM/yyyy')))"),
    @('Sistema', "$($os.Caption) $($os.OSArchitecture) — versão $($os.Version)"),
    @('Ligado há', ("{0} dias, {1} h {2} min" -f [int][math]::Floor($uptime.TotalDays), $uptime.Hours, $uptime.Minutes)),
    @('Temperatura (ACPI)', $(if ($temps.Count) { ($temps | ForEach-Object { "$_ °C" }) -join ', ' } else { 'Não informada por este PC' })))) + "</table></section>"

if ($bat.Count) {
    $sec += "<section><h2>Bateria</h2><table>" + (Linhas @(
        @('Carga', "$([math]::Min(100, [int]$bat[0].EstimatedChargeRemaining))%"),
        @('Desgaste', $(if ($desgaste -ne $null) { "$desgaste% da capacidade original perdida" } else { 'Não informado' })))) + "</table></section>"
}
if ($redes.Count) {
    $sec += "<section><h2>Rede</h2><table class='lista'><tr><th>Adaptador</th><th>Velocidade</th></tr>" +
        (($redes | ForEach-Object { "<tr><td>$(Esc $_.InterfaceDescription)</td><td>$(Esc $_.LinkSpeed)</td></tr>" }) -join '') + "</table></section>"
}

$selo = @{ ruim = 'Grave'; aviso = 'Atenção'; info = 'Dica' }
$ordem = @{ ruim = 0; aviso = 1; info = 2 }
$resumo = (@(
    $(if ($graves) { "<span class='ruim'>$graves grave$(if ($graves -gt 1) { 's' })</span>" }),
    $(if ($atencao) { "<span class='aviso'>$atencao de atenção</span>" }),
    $(if ($dicas) { "<span class='info'>$dicas dica$(if ($dicas -gt 1) { 's' })</span>" })) | Where-Object { $_ }) -join ' · '
$cartoes = if (-not ($problemas | Where-Object Nivel -ne 'info')) {
    "<div class='prob ok'><div class='cab'><span class='selo'>Tudo certo</span><h3>Nenhum problema encontrado</h3></div><p>O hardware deste computador está em ordem.</p></div>"
} else { '' }
$cartoes += ($problemas | Sort-Object { $ordem[$_.Nivel] } | ForEach-Object {
    "<div class='prob $($_.Nivel)'><div class='cab'><span class='selo'>$($selo[$_.Nivel])</span><h3>$(Esc $_.Titulo)</h3></div>" +
    "<p>$(Esc $_.Explicacao)</p>" +
    $(if ($_.Detalhes) { "<ul class='det'>" + (($_.Detalhes | ForEach-Object { "<li>$(Esc $_)</li>" }) -join '') + '</ul>' }) +
    "<h4>Como resolver</h4><ol>" + (($_.Passos | Where-Object { $_ } | ForEach-Object { "<li>$(Esc $_)</li>" }) -join '') + '</ol></div>'
}) -join "`n"

$logoB64 = if (Test-Path -LiteralPath $logoArq) { [Convert]::ToBase64String([IO.File]::ReadAllBytes($logoArq)) }
$logoTag = if ($logoB64) { "<img class='logo' alt='Soluções da Internet' src='data:image/png;base64,$logoB64'>" } else { '' }

$html = @"
<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Análise de Hardware — $(Esc $cs.Name)</title>$(if ($logoB64) { "<link rel='icon' href='data:image/png;base64,$logoB64'>" })<style>
:root{--bg:#f4f5f7;--card:#fff;--tx:#1d2330;--mut:#667085;--ln:#e4e7ec;--ok:#12805c;--aviso:#b86e00;--ruim:#c0362c;--info:#2f62c9}
@media(prefers-color-scheme:dark){:root{--bg:#12151b;--card:#1b1f27;--tx:#e6e8ec;--mut:#98a1b2;--ln:#2b313c;--ok:#3ecf8e;--aviso:#f0a92e;--ruim:#f26b5e;--info:#6d9bff}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.5 "Segoe UI",system-ui,sans-serif}
main{max-width:980px;margin:0 auto;padding:24px 16px 48px}
header{display:flex;flex-wrap:wrap;gap:16px;align-items:center;justify-content:space-between;margin-bottom:20px}
h1{margin:0;font-size:26px}header p{margin:2px 0 0;color:var(--mut)}
.nota{text-align:center;background:var(--card);border:1px solid var(--ln);border-radius:14px;padding:10px 22px}
.nota b{display:block;font-size:34px;line-height:1.1}.nota small{color:var(--mut)}
section{background:var(--card);border:1px solid var(--ln);border-radius:14px;padding:18px 20px;margin-bottom:16px;overflow-x:auto}
h2{margin:0 0 10px;font-size:17px}h3{font-size:14px;color:var(--mut);margin:16px 0 6px}
table{border-collapse:collapse;width:100%;margin-bottom:8px}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--ln);vertical-align:top}
table:not(.lista) th{width:34%;color:var(--mut);font-weight:500}.lista th{color:var(--mut);font-weight:500;font-size:13px;white-space:nowrap}
.barra{height:8px;background:var(--ln);border-radius:4px;overflow:hidden;margin:4px 0 12px}.barra span{display:block;height:100%}
.barra .ok{background:var(--ok)}.barra .aviso{background:var(--aviso)}.barra .ruim{background:var(--ruim)}
b.ok,.ok>span{color:var(--ok)}b.ruim,.ruim>span{color:var(--ruim)}.aviso>span{color:var(--aviso)}.info>span{color:var(--info)}
.nota .ok{color:var(--ok)}.nota .aviso{color:var(--aviso)}.nota .ruim{color:var(--ruim)}
.resumo{margin:-4px 0 14px;font-weight:600}.resumo .ruim{color:var(--ruim)}.resumo .aviso{color:var(--aviso)}.resumo .info{color:var(--info)}
.prob{border:1px solid var(--ln);border-left:4px solid var(--c);border-radius:10px;padding:14px 16px;margin-bottom:12px}
.prob.ruim{--c:var(--ruim)}.prob.aviso{--c:var(--aviso)}.prob.info{--c:var(--info)}.prob.ok{--c:var(--ok)}
.prob .cab{display:flex;flex-wrap:wrap;align-items:center;gap:10px}.prob h3{margin:0;font-size:16px;color:var(--tx)}
.selo{background:var(--c);color:#fff;font-size:12px;font-weight:700;border-radius:20px;padding:2px 10px;text-transform:uppercase;letter-spacing:.03em}
@media(prefers-color-scheme:dark){.selo{color:#12151b}}
.prob p{margin:8px 0}.prob h4{margin:10px 0 4px;font-size:13px;color:var(--mut);text-transform:uppercase;letter-spacing:.04em}
.prob ol{margin:0;padding-left:22px}.prob ol li{margin:3px 0}
.det{margin:4px 0 8px;padding:8px 12px 8px 28px;background:var(--bg);border-radius:8px;font-size:14px;color:var(--mut)}
.vol{display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;font-size:14px}.vol span:last-child{color:var(--mut)}
.marca{display:flex;align-items:center;gap:16px}.logo{height:72px;background:#fff;border-radius:12px;padding:6px 10px;border:1px solid var(--ln)}
footer{color:var(--mut);font-size:13px;text-align:center}
</style></head><body><main>
<header><div class="marca">$logoTag<div><h1>Análise de Hardware</h1><p><b>$(Esc $cs.Name)</b> · $(Get-Date -Format 'dd/MM/yyyy HH:mm')</p></div></div>
<div class="nota"><b class="$notaCls">$nota</b><small>$notaTxt</small></div></header>
<section><h2>Problemas encontrados e como resolver</h2>$(if ($resumo) { "<p class='resumo'>$resumo</p>" })
$cartoes</section>
$($sec -join "`n")
<footer>Algumas informações (temperatura, desgaste de disco) só aparecem se o PC as fornece ou se o programa for executado como administrador.</footer>
</main></body></html>
"@

# Salva ao lado do programa (ex.: no pen drive); se não der (pasta só leitura), salva na Área de Trabalho.
$nome = "Solucoes_da_Internet_Hardware_{0}_{1}.html" -f ($cs.Name -replace '[^\w-]', '_'), (Get-Date -Format 'yyyy-MM-dd_HHmm')
$arq = $null
# na versão do site o programa fica em 'arquivos\': os relatórios vão para a pasta de cima, ao lado do 'CLIQUE AQUI'
$base = if ((Split-Path $PSScriptRoot -Leaf) -eq 'arquivos') { Split-Path $PSScriptRoot } else { $PSScriptRoot }
foreach ($pasta in (Join-Path $base 'Relatorios'), [Environment]::GetFolderPath('Desktop'), $env:TEMP) {
    try {
        New-Item -ItemType Directory -Force -Path $pasta -ErrorAction Stop | Out-Null
        $arq = Join-Path $pasta $nome
        [IO.File]::WriteAllText($arq, $html, (New-Object Text.UTF8Encoding $true))
        break
    } catch { $arq = $null }
}
Etapa 'Pronto!' 100
$tela.Close()
if (-not $arq) { Aviso 'Não foi possível salvar o relatório.'; exit 1 }
Write-Host "Relatório salvo em: $arq"
if ($Saida) { Set-Content -LiteralPath $Saida -Value $arq -Encoding UTF8 }   # a cópia normal abre a janela
elseif (-not $env:SEM_ABRIR) { AbrirJanela $arq }
