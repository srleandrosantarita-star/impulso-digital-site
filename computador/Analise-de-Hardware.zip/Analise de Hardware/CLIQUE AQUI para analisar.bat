@echo off
rem Analise de Hardware - Solucoes da Internet
rem Roda o programa que esta na mesma pasta deste arquivo (ou na subpasta "arquivos", na versao do site).
set "PROG=%~dp0AnaliseHardware.ps1"
if exist "%~dp0arquivos\AnaliseHardware.ps1" set "PROG=%~dp0arquivos\AnaliseHardware.ps1"
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%PROG%"
