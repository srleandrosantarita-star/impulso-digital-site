@echo off
rem Analise de Hardware - Solucoes da Internet
rem Roda o programa que esta na mesma pasta deste arquivo (funciona em pen drive e pasta de rede).
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0AnaliseHardware.ps1"
